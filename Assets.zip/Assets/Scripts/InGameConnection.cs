﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking; 

public class InGameConnection : MonoBehaviour {
    MyNetworkManager manager;
    [HideInInspector]
    public GameObject localPlayer; 

	void Start () {
        manager = GameObject.Find("NetworkManager").GetComponent<MyNetworkManager>();
	}
	
    public void quitGame () {
        if (manager.isHost) {
            print("kill host");
            manager.StopClient();
            NetworkManager.singleton.StopHost();
        } else {
            print("kill client");
            manager.StopClient(); 
        }
    }
}
