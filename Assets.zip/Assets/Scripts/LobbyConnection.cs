﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking; 

public class LobbyConnection : MonoBehaviour {
    //this behaviour is needed becamse manager is in dontdestroyonload thus
    //functions for a button cannot be directly attached
    [HideInInspector]
    public MyNetworkManager manager;
    private void Start() {
        manager = GameObject.Find("NetworkManager").GetComponent<MyNetworkManager>(); 
    }
    public void hostGame () {
        manager.hostGame(); 
    }
    public void joinGame () {
        manager.joinGame(); 
    }
}
