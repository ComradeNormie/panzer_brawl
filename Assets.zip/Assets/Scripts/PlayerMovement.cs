﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class PlayerMovement : MonoBehaviour {
    PlayerDamage damageComponent; 
    float interval = 0.1f;
    float localRotationX = 0;

    private void Start() {
        damageComponent = GetComponent<PlayerDamage>(); 
    }
    void Update () {
        interval -= Time.deltaTime;
        if (interval < 0) {
            interval = 0.1f;
            GetComponent<PlayerNetworker>().updatePos(damageComponent.health, transform, transform.GetChild(0), transform.GetChild(1)); 
        }
        if (damageComponent.respawnInProgress)
            return; 
        //change movement so that it is actually only horizontal movement (cannot increase y axis when facing upwards)
        Quaternion prevRotation = transform.rotation;
        //transform.rotation = Quaternion.Euler(0, transform.eulerAngles.y, 0);
        if (Input.GetKey(KeyCode.W)) {
			transform.Translate (Vector3.forward * 2.4f * Time.deltaTime, Space.Self);
		}
		
		if (Input.GetKey(KeyCode.S)) {
			transform.Translate (Vector3.back * 2.4f * Time.deltaTime, Space.Self);
		}
        //transform.rotation = prevRotation;

        if (Input.GetKey(KeyCode.A)) {
            transform.Rotate(new Vector3(0, -Time.deltaTime * 30, 0), Space.Self);
        }
        if (Input.GetKey(KeyCode.D)) {
            transform.Rotate(new Vector3(0, Time.deltaTime * 30, 0), Space.Self);
        }

        if (Input.GetKey(KeyCode.LeftArrow)) {
			transform.GetChild(0).Rotate (new Vector3(0, -Time.deltaTime * 28, 0), Space.Self);
		}
		if (Input.GetKey(KeyCode.RightArrow)) {
			transform.GetChild(0).Rotate (new Vector3(0, Time.deltaTime * 28, 0), Space.Self);
		}
        if (Input.GetKey(KeyCode.UpArrow) && localRotationX > -16f) {
            transform.GetChild(1).Rotate(new Vector3(-Time.deltaTime * 20, 0, 0), Space.Self);
            localRotationX += -Time.deltaTime * 17; 
        }
        if (Input.GetKey(KeyCode.DownArrow) && localRotationX < 5.8f) {
            transform.GetChild(1).Rotate(new Vector3(Time.deltaTime * 20, 0, 0), Space.Self);
            localRotationX += Time.deltaTime * 17; 
        }
        fixGunToTurret(); 
    }
    void fixGunToTurret () {
        //only y axis (horizontal rotation)
        transform.GetChild(1).localPosition = new Vector3(0, 0.25f, 0.301f);
        transform.GetChild(1).localRotation = Quaternion.Euler(0, transform.GetChild(0).localEulerAngles.y, 0);
        transform.GetChild(1).Rotate(new Vector3(localRotationX, 0, 0));
        transform.GetChild(1).Translate(new Vector3(0, 0, -GetComponent<PlayerShoot>().recoilDistance));
    }
}
