﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDamage : MonoBehaviour {
    public bool respawnInProgress = false; 
	public float maxHealth;
	public float health;
    [HideInInspector]
	public GameObject healthDisplay;
    [HideInInspector]
    public MyNetworkManager networkManager; 

	void Start () {
		healthDisplay = GameObject.Find ("HealthDisplay");
        networkManager = GameObject.Find("NetworkManager").GetComponent<MyNetworkManager>();
	}
	void updateHealthBar () {
		healthDisplay.GetComponent<RectTransform> ().sizeDelta = new Vector2 (healthDisplay.transform.parent.GetComponent<RectTransform> ().sizeDelta.x * (health / maxHealth), healthDisplay.GetComponent<RectTransform> ().sizeDelta.y);
	}
	void Update () {
		if (health <= 0 && !respawnInProgress) {
			GetComponent<PlayerNetworker> ().CmdExplosion (gameObject);
            //add points to hitter in playerShoot later
            StartCoroutine(respawnPlayer()); 
		}
	}
    IEnumerator respawnPlayer () {
        for (float i = 0; i < 4; i += Time.deltaTime) {
            respawnInProgress = true; 
            yield return null; 
        }
        //respawn now
        int rand = Random.Range(0, networkManager.transform.childCount - 1);
        transform.position = networkManager.transform.GetChild(rand).position;
        transform.rotation = Quaternion.identity;
        health = maxHealth;
        respawnInProgress = false; 

        yield return new WaitForSeconds(0f); 
    }
    public void loseHealth (float damage) {
        health -= damage; 
        updateHealthBar();
    }
}
