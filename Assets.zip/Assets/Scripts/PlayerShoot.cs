﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class PlayerShoot : MonoBehaviour {
	public float reloadTime;
	float reloadCountdown;
    public float recoilDistance; 

	void Start () {}

	void Update () {
		if (reloadCountdown > 0) {
			if (reloadCountdown > reloadTime - 0.25f) {
				//transform.GetChild (1).Translate (Vector3.forward * Time.deltaTime);
                recoilDistance -= Time.deltaTime; 
			} else {
                //transform.GetChild(1).localPosition = new Vector3(0, 0.25f, 0.277f);
                recoilDistance = 0;
            }
            reloadCountdown -= Time.deltaTime;
		} else {
            //transform.GetChild(1).localPosition = new Vector3(0, 0.25f, 0.301f);
            recoilDistance = 0;
        }
        if (Input.GetKeyDown (KeyCode.F) && reloadCountdown <= 0) {
			transform.GetChild (1).Translate (Vector3.back * 0.25f);
			GetComponent<PlayerNetworker> ().shoot (gameObject);
			reloadCountdown = reloadTime;
            recoilDistance = 0.25f; 
		}
	}
}
