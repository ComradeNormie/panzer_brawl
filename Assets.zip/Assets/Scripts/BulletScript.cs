﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScript : MonoBehaviour {
    public GameObject explosionPrefab;
    float delay = 0.1f; 
	public float damage;
	[HideInInspector]
	public GameObject parent;
	public float lifeTime = 3;
	void Start () {
		damage *= Random.Range (0.8f, 1.2f);
		transform.Translate (new Vector3(0, 0f, 1.6f), Space.Self);
	}

	void Update () {
        transform.Translate(Vector3.forward * Time.deltaTime * 18, Space.Self);
        if (delay > 0)
            delay -= Time.deltaTime;
        else {
            foreach (Collider i in Physics.OverlapBox(transform.position, new Vector3(0.05f, 0.05f, 0.05f))) {
                if ((i.GetComponent<PlayerNetworker>() != null || i.transform.parent != null && i.transform.parent.GetComponent<PlayerNetworker>() != null && parent != i.transform.parent.gameObject) && parent != i.gameObject) {
                    if (i.GetComponent<PlayerNetworker>() != null) {
                        if (i.GetComponent<PlayerNetworker>().isLocalPlayer) {
                            i.GetComponent<PlayerDamage>().loseHealth(damage);
                        }
                    } else {
                        if (i.transform.parent.GetComponent<PlayerNetworker>().isLocalPlayer) {
                            i.transform.parent.GetComponent<PlayerDamage>().loseHealth(damage);
                        }
                    }
                    Instantiate(explosionPrefab, transform.position, explosionPrefab.transform.rotation);
                    Destroy(gameObject);
                    return;
                }
                if (i.gameObject != gameObject) {
                    Instantiate(explosionPrefab, transform.position, explosionPrefab.transform.rotation);
                    Destroy(gameObject);
                }
                return;
            }
        }
        lifeTime -= Time.deltaTime;
        if (lifeTime <= 0)
            Destroy(gameObject);
	}
}


