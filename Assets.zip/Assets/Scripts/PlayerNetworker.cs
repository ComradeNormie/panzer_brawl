﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class PlayerNetworker : NetworkBehaviour {
	public GameObject explosionPrefab;
	public GameObject bulletPrefab;
	[SerializeField]
	Behaviour[] componentsToDisable;
	[SyncVar]
	public bool isShoot;
	[SyncVar]
	public bool isExplosion;
    [SyncVar]
    public float health; 
	bool prevShoot;
	bool prevExplosion;
    //shoottarget is the target
	[SyncVar]
	public GameObject shootTarget;
    [SyncVar]
    public float posX, posY, posZ, rotX, rotY, rotZ, rotX1, rotY1, rotZ1, posX1, posY1, posZ1, rotX2, rotY2, rotZ2;
    //this is for syncing
    Vector3 prevPos, prevRot, prevRot1, prevPos1, prevRot2;

    void Update() {
        if (prevShoot != isShoot)
            ClientShoot(shootTarget);
        if (prevExplosion != isExplosion)
            ClientExplode(shootTarget);
        if (prevPos != new Vector3(posX, posY, posZ) || prevRot != new Vector3(rotX, rotY, rotZ) || prevRot1 != new Vector3(rotX1, rotY1, rotZ1) || prevPos1 != new Vector3(posX1, posY1, posZ1) || prevRot2 != new Vector3(rotX2, rotY2, rotZ2))
            ClientUpdatePosition();
		prevShoot = isShoot;
        prevExplosion = isExplosion; 
        prevPos = new Vector3(posX, posY, posZ);
        prevPos1 = new Vector3(posX1, posY1, posZ1);
        prevRot = new Vector3(rotX, rotY, rotZ);
        prevRot1 = new Vector3(rotX1, rotY1, rotZ1);
        prevRot2 = new Vector3(rotX2, rotY2, rotZ2);
    }
	void Start () {
		if (!isLocalPlayer) {
			foreach (Behaviour i in componentsToDisable) {
				i.enabled = false;
			}
		} else {
            GameObject.Find("Camera").GetComponent<Camera>().enabled = false;
        }
    }
	public void shoot (GameObject p) {
		CmdShoot (p);
	}
    public void updatePos (float hp, Transform t, Transform t1, Transform t2) {
        CmdUpdatePos(hp, t.position.x, t.position.y, t.position.z, t.eulerAngles.x, t.eulerAngles.y, t.eulerAngles.z, t1.eulerAngles.x, t1.eulerAngles.y, t1.eulerAngles.z, t2.position.x, t2.position.y, t2.position.z, t2.eulerAngles.x, t2.eulerAngles.y, t2.eulerAngles.z); 
    }
    [Command]
	public void CmdShoot (GameObject p) {
        isShoot = !isShoot;

		shootTarget = p;
	}
    [Command]
	public void CmdExplosion (GameObject p) {
		isExplosion = !isExplosion;
		shootTarget = p;
	}
    [Command]
    public void CmdUpdatePos (float hp, float x, float y, float z, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4) {
        rotX = x1;
        rotY = y1;
        rotZ = z1;
        rotX1 = x2;
        rotY1 = y2;
        rotZ1 = z2; 
        posX = x;
        posY = y;
        posZ = z;
        posX1 = x3;
        posY1 = y3;
        posZ1 = z3;
        rotX2 = x4;
        rotY2 = y4;
        rotZ2 = z4;
        health = hp; 
    }
    [Client]
	public void ClientExplode (GameObject p) {
		Instantiate (explosionPrefab, p.transform.position, explosionPrefab.transform.rotation);
	}
	[Client]
	public void ClientShoot (GameObject p) {
		GameObject insItem = Instantiate (bulletPrefab, p.transform.GetChild(1).position, p.transform.GetChild(1).rotation) as GameObject;
		insItem.GetComponent<BulletScript> ().parent = p;
	}
    [Client]
    public void ClientUpdatePosition() {
        if (!isLocalPlayer) {
            transform.position = new Vector3(posX, posY, posZ);
            transform.rotation = Quaternion.Euler(rotX, rotY, rotZ);
            transform.GetChild(0).rotation = Quaternion.Euler(rotX1, rotY1, rotZ1);
            transform.GetChild(1).position = new Vector3(posX1, posY1, posZ1);
            transform.GetChild(1).rotation = Quaternion.Euler(rotX2, rotY2, rotZ2);
        }

    }

}
