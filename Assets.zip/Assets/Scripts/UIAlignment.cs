﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIAlignment : MonoBehaviour {
	public float scale;
	void Awake () {
		//align scale and anchored position to fit device measurements
		scale = Screen.width / 900f;

		if (GetComponent<Text> () != null) {
			GetComponent<Text> ().fontSize = (int)(GetComponent<Text> ().fontSize * scale);
		} else {
			GetComponent<RectTransform>().anchoredPosition = new Vector2 (GetComponent<RectTransform>().anchoredPosition.x * scale, GetComponent<RectTransform>().anchoredPosition.y * scale);
			GetComponent<RectTransform>().sizeDelta = new Vector2 (GetComponent<RectTransform>().rect.width * scale, GetComponent<RectTransform>().rect.height * scale);
		}
	}
}
