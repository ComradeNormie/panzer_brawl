﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Networking.NetworkSystem;
using System.Net.NetworkInformation; 

public class MyNetworkManager : NetworkManager {
    //currenthost is reset as soon as scene changes but ishost remains same
    public bool isHost;
    bool currentHost;
    bool connectingClient;
    NetworkDiscovery discovery;
    string userIp = ""; 

    bool hostWait = false, joinWait = false;

    private void Start() {
        discovery = GetComponent<NetworkDiscovery>();

        //code from https://www.cnblogs.com/hewencong/p/4202441.html
        NetworkInterface[] adapters = NetworkInterface.GetAllNetworkInterfaces(); ;
        foreach (NetworkInterface adapter in adapters) {
            if (adapter.Supports(NetworkInterfaceComponent.IPv4)) {
                UnicastIPAddressInformationCollection uniCast = adapter.GetIPProperties().UnicastAddresses;
                if (uniCast.Count > 0) {
                    foreach (UnicastIPAddressInformation uni in uniCast) { 
                        //IPv4
                        if (uni.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork) {
                            userIp = uni.Address.ToString();
                            print(userIp);
                            if (userIp != "127.0.0.1") {
                                networkAddress = userIp;
                                serverBindAddress = userIp; 
                            }
                        }
                    }
                }
            }
        }
        //code end
    }
    public void hostGame () {
        SceneManager.LoadScene(1);
        hostWait = true; 
    }
    public void joinGame () {
        SceneManager.LoadScene(1);
        joinWait = true; 
    }

    private void Update() {
        if (SceneManager.GetActiveScene().name == "GameScene" && hostWait) {
            hostWait = false;
            if (!connectingClient) {
                //broadcast
                discovery.Initialize();
                discovery.StartAsServer(); 
                isHost = true;
                currentHost = true;
                StartHost();
            }
        }
        if (SceneManager.GetActiveScene().name == "GameScene" && joinWait) {
            joinWait = false;
            //first listen for broadcast, if found server will [change later] join the first one
            discovery.Initialize();
            discovery.StartAsClient();
        }
    }
    //will be triggered by mynetworkdiscovery
    public void receivedBroadcast (string fromAddress, string data) {
        //todo: found a server; later this function should be repeatedly called and values put into a list/array
        discovery.StopBroadcast();
        fromAddress = fromAddress.Substring(7);
        networkAddress = fromAddress; 
        joinWait = false;
        connectingClient = true;
        //checked because host also runs client
        if (!currentHost)
            isHost = false;
        //network discovery find broadcasted address
        StartClient();
    }
    public override void OnStartClient(NetworkClient client) {
        base.OnStartClient(client); 
        //host runs this as well
        currentHost = false; 

    }

    public override void OnClientConnect(NetworkConnection conn) {
        base.OnClientConnect(conn);
    }
    public override void OnStopHost() {
        base.OnStopHost();
        //stop broadcasting
        discovery.StopBroadcast(); 
        SceneManager.LoadScene(0);
    }
    public override void OnStopClient() {
        connectingClient = false; 
        base.OnStopClient();
        //stop listening 
        discovery.StopBroadcast();
        SceneManager.LoadScene(0);
    }
}
